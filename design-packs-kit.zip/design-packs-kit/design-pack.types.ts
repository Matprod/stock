// Contrat d'un pack de design pour rapports de données sportives. Les jetons sont du code, pas du texte libre :
// le Designer ne les écrit jamais, il choisit un identifiant de pack.

export type PackId = 'staff' | 'medical' | 'performance' | 'editorial' | 'controlroom';
export type Hex = `#${string}`;
export type HueName = 'blue' | 'orange' | 'aqua' | 'yellow' | 'magenta' | 'green' | 'violet' | 'red';

export interface StatusToken { fill: Hex; text: Hex; soft: Hex }   // text est mesuré sur soft, card et paper (>= 4,6:1)

export interface SurfaceTokens {
  paper: Hex; card: Hex; ink: Hex; ink2: Hex; muted: Hex; faint: Hex; line: Hex;
  accent: Hex; accentText: Hex; accentSoft: Hex;
  status: { risk: StatusToken; watch: StatusToken; ok: StatusToken };
  under: Hex; underText: Hex;                                      // « inexploitable » : gris, jamais un statut de risque
}

export interface DivergingTokens { good: Hex[]; mid: Hex; bad: Hex[] }   // du centre vers l'extrême ; good = amélioration, bad = dégradation

export interface DesignPack {
  label: string; usage: string; mood: string;
  fonts: { display: string; body: string; data: string; weights: { display: number[]; body: number[]; data: number[] } };
  density: number;                                                  // alimente --space
  typePt: { h1: number; h2: number; body: number; caption: number; data: number };
  series: { names: HueName[]; light: Hex[]; dark?: Hex[] };         // 'red' toujours en dernier : couleur réservée aux statuts
  sequential: { hue: string; light: Hex[]; dark?: Hex[] };
  diverging: { light: DivergingTokens; dark?: DivergingTokens };
  light: SurfaceTokens;                                             // écran clair ET impression
  dark?: SurfaceTokens;                                             // écran sombre ; l'impression bascule toujours sur `light`
  chart: { axisFontPx: number; legendFontPx: number; titleFontPx: number; lineWidth: number; symbolSize: number; barRadius: number; barGapPx: number; gridDash: 'solid' | 'dashed'; dashByIndex: string[]; symbolByIndex: string[] };
  zones: { metric: 'acwr'; thresholds: [number, number, number]; labels: [string, string, string, string]; note: string };
}

export interface PackFile { version: 1; generatedBy: string; packs: Record<PackId, DesignPack> }
