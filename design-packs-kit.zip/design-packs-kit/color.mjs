// Utilitaires couleur : sRGB <-> OKLab/OKLCH, contraste WCAG, mélange, recherche de teinte accessible.
export const hex2rgb = h => { h=h.replace('#',''); if(h.length===3) h=[...h].map(c=>c+c).join(''); return [0,2,4].map(i=>parseInt(h.slice(i,i+2),16)/255); };
export const rgb2hex = c => '#'+c.map(v=>Math.round(Math.min(1,Math.max(0,v))*255).toString(16).padStart(2,'0')).join('');
const lin = v => v<=0.04045? v/12.92 : ((v+0.055)/1.055)**2.4;
const gam = v => v<=0.0031308? v*12.92 : 1.055*v**(1/2.4)-0.055;
export function hex2oklab(h){ const [r,g,b]=hex2rgb(h).map(lin);
  const l=Math.cbrt(0.4122214708*r+0.5363325363*g+0.0514459929*b), m=Math.cbrt(0.2119034982*r+0.6806995451*g+0.1073969566*b), s=Math.cbrt(0.0883024619*r+0.2817188376*g+0.6299787005*b);
  return [0.2104542553*l+0.793617785*m-0.0040720468*s, 1.9779984951*l-2.428592205*m+0.4505937099*s, 0.0259040371*l+0.7827717662*m-0.8086757660*s]; }
export function oklab2rgb([L,a,b]){ const l=(L+0.3963377774*a+0.2158037573*b)**3, m=(L-0.1055613458*a-0.0638541728*b)**3, s=(L-0.0894841775*a-1.2914855480*b)**3;
  return [4.0767416621*l-3.3077115913*m+0.2309699292*s, -1.2684380046*l+2.6097574011*m-0.3413193965*s, -0.0041960863*l-0.7034186147*m+1.7076147010*s].map(gam); }
export const hex2oklch = h => { const [L,a,b]=hex2oklab(h); return [L,Math.hypot(a,b),(Math.atan2(b,a)*180/Math.PI+360)%360]; };
const inGamut = rgb => rgb.every(v=>v>=-0.0005&&v<=1.0005);
export function oklch2hex(L,C,H){ let c=C; for(let i=0;i<60;i++){ const rgb=oklab2rgb([L,c*Math.cos(H*Math.PI/180),c*Math.sin(H*Math.PI/180)]); if(inGamut(rgb)) return rgb2hex(rgb); c*=0.96; } return rgb2hex(oklab2rgb([L,0,0])); }
const relLum = h => { const [r,g,b]=hex2rgb(h).map(lin); return 0.2126*r+0.7152*g+0.0722*b; };
export const contrast = (a,b) => { const [hi,lo]=[relLum(a),relLum(b)].sort((x,y)=>y-x); return (hi+0.05)/(lo+0.05); };
export const mix = (a,b,t) => { const A=hex2rgb(a),B=hex2rgb(b); return rgb2hex(A.map((v,i)=>v*(1-t)+B[i]*t)); };
// Assombrit (fond clair) ou éclaircit (fond sombre) une teinte jusqu'à atteindre le contraste demandé, en gardant la teinte.
export function accessible(hex, surface, min=4.5){ const S=[].concat(surface); let [L,C,H]=hex2oklch(hex); const dir = relLum(S[0])>0.5 ? -1 : 1;
  for(let i=0;i<300 && Math.min(...S.map(s=>contrast(oklch2hex(L,C,H),s)))<min;i++) L+=dir*0.005; return oklch2hex(L,C,H); }
// Rampe séquentielle à une teinte : de clair à foncé, L monotone.
export function ramp(hue, steps=7, Lhi=0.93, Llo=0.36, Cpeak=0.15){ return Array.from({length:steps},(_,i)=>{ const t=i/(steps-1); const L=Lhi+(Llo-Lhi)*t; const C=Cpeak*Math.sin(Math.PI*(0.15+0.7*t)); return oklch2hex(L,Math.max(C,0.02),hue); }); }
