import fs from 'node:fs';
import { accessible, mix, ramp, oklch2hex, hex2oklch } from './color.mjs';

const LIGHT = {blue:'#2a78d6',orange:'#eb6834',aqua:'#1baf7a',yellow:'#eda100',magenta:'#e87ba4',green:'#008300',violet:'#6250d6',red:'#e34948'};
const DARK  = {blue:'#3987e5',orange:'#d95926',aqua:'#199e70',yellow:'#c98500',magenta:'#d55181',green:'#008300',violet:'#9085e9',red:'#e66767'};
const seq = (order, pal) => order.map(h => pal[h]);
const BLUE_REF = ['#cde2fb','#9ec5f4','#6da7ec','#3987e5','#256abf','#184f95','#0d366b']; // rampe de référence validée (étapes 100,200,300,400,500,600,700)
const STATUS = { risk:'#d03b3b', watch:'#fab219', ok:'#0ca30c' };                           // statuts réservés, jamais des séries
const DIVERGING = (mid, mode) => { // gauche = amélioration (bleu), droite = dégradation (rouge), milieu neutre
  const L = mode==='dark' ? [0.42,0.50,0.58,0.66] : [0.85,0.72,0.60,0.50]; // du centre vers l'extrême : plus clair à l'écran sombre, plus foncé sur papier
  
  const arm = h => L.map(l => oklch2hex(l, 0.13, h));
  const good = arm(255), bad = arm(25);
  return { good, mid, bad };
};
const common = { chart:{ axisFontPx:11, legendFontPx:11, titleFontPx:12, lineWidth:2, symbolSize:7, barRadius:4, barGapPx:2, gridDash:'solid',
    dashByIndex:['solid','dashed','dotted','dashed','solid','dotted','dashed','solid'], symbolByIndex:['circle','rect','triangle','diamond','roundRect','pin','arrow','circle'] },
  zones:{ metric:'acwr', thresholds:[0.8,1.3,1.5], labels:['sous-charge','zone cible','vigilance','risque élevé'],
    note:'Seuils usuels dans la littérature, discutés. À configurer par club ; ne jamais les coder en dur dans le rendu.' } };

function lightTokens({paper,card,ink,ink2,muted,faint,line,accent}){
  const accentText = accessible(accent, paper, 4.5);
  const status = {};
  for(const k of Object.keys(STATUS)){ const soft=mix(paper, STATUS[k], 0.10); const text=accessible(STATUS[k], [soft,card,paper], 4.6); status[k]={ fill:STATUS[k], text, soft }; }
  return { paper, card, ink, ink2, muted, faint, line, accent, accentText, accentSoft: mix(paper, accent, 0.09), status, under:'#94A3B8', underText: accessible('#94A3B8', card, 4.5) };
}
function darkTokens({paper,card,ink,ink2,muted,faint,line,accent}){
  const status = {}; for(const k of Object.keys(STATUS)){ const soft=mix(paper, STATUS[k], 0.14); const text=accessible(STATUS[k], [soft,card,paper], 4.6); status[k]={ fill:STATUS[k], text, soft }; }
  return { paper, card, ink, ink2, muted, faint, line, accent, accentText: accessible(accent, card, 4.5), accentSoft: mix(paper, accent, 0.12), status, under:'#64748B', underText: accessible('#64748B', card, 4.5) };
}
const rampFor = hue => ramp(hue, 7, 0.93, 0.36, 0.15);

const packs = {
  staff: { label:'Staff', usage:'Rapport staff par défaut : blessures, risque, wellness, charge. Dense, sobre, marque MAUNA.',
    mood:'marine, blanc, grille nette, chiffres en police technique',
    fonts:{ display:'Sora', body:'IBM Plex Sans', data:'IBM Plex Mono', weights:{ display:[600,700], body:[400,500,600], data:[400,500] } },
    density:0.95, typePt:{ h1:25, h2:15, body:9.5, caption:8, data:7.5 },
    series:{ names:['blue','orange','aqua','yellow','magenta','green','violet','red'], light:seq(['blue','orange','aqua','yellow','magenta','green','violet','red'],LIGHT), dark:seq(['blue','orange','aqua','yellow','magenta','green','violet','red'],DARK) },
    sequential:{ hue:'blue', light:BLUE_REF, dark:BLUE_REF.slice().reverse() },
    light: lightTokens({paper:'#FFFFFF',card:'#F6F8FA',ink:'#0F172A',ink2:'#334155',muted:'#5B6B80',faint:'#94A3B8',line:'#E2E8F0',accent:'#0B3C5D'}),
    diverging:{ light: DIVERGING('#F0EFEC','light'), dark: DIVERGING('#383835','dark') } },
  medical: { label:'Médical', usage:'Blessures, retours au jeu, biomarqueurs, suivi médical. Lecture clinique, aucune décoration.',
    mood:'blanc froid, vert-bleu sobre, fort contraste du texte, statuts très lisibles',
    fonts:{ display:'Public Sans', body:'Public Sans', data:'JetBrains Mono', weights:{ display:[600,700], body:[400,500,600], data:[400,500] } },
    density:1.0, typePt:{ h1:23, h2:14.5, body:9.5, caption:8, data:7.5 },
    series:{ names:['aqua','blue','orange','violet','magenta','green','yellow','red'], light:seq(['aqua','blue','orange','violet','magenta','green','yellow','red'],LIGHT) },
    sequential:{ hue:'aqua', light:rampFor(162) },
    light: lightTokens({paper:'#FFFFFF',card:'#F2F7F7',ink:'#10201F',ink2:'#2F4443',muted:'#546B6A',faint:'#8FA3A2',line:'#DCE7E6',accent:'#0F766E'}),
    diverging:{ light: DIVERGING('#EEF0EF','light') } },
  performance: { label:'Performance', usage:'GPS, charge interne et externe, ACWR, comparaison de séances. Tableaux serrés, séries nombreuses.',
    mood:'blanc, orange vif en tête, titres condensés, très dense',
    fonts:{ display:'Barlow Condensed', body:'Barlow', data:'JetBrains Mono', weights:{ display:[600,700], body:[400,500,600], data:[400,500] } },
    density:0.88, typePt:{ h1:28, h2:16.5, body:9.5, caption:8, data:7.5 },
    series:{ names:['orange','blue','aqua','violet','magenta','green','yellow','red'], light:seq(['orange','blue','aqua','violet','magenta','green','yellow','red'],LIGHT) },
    sequential:{ hue:'orange', light:rampFor(41) },
    light: lightTokens({paper:'#FFFFFF',card:'#F7F7F5',ink:'#14120F',ink2:'#3A3631',muted:'#645E56',faint:'#A09A90',line:'#E6E2DB',accent:'#C2410C'}),
    diverging:{ light: DIVERGING('#F0EFEC','light') } },
  editorial: { label:'Éditorial', usage:'Synthèse pour la direction ou la présidence : peu de chiffres, grandes figures, lecture rapide.',
    mood:'papier chaud, titres en empattement, couleurs retenues, beaucoup d\'espace',
    fonts:{ display:'Fraunces', body:'Source Sans 3', data:'IBM Plex Mono', weights:{ display:[500,600], body:[400,500,600], data:[400,500] } },
    density:1.12, typePt:{ h1:27, h2:16, body:10, caption:8.5, data:8 },
    series:{ names:['violet','orange','aqua','blue','magenta','green','yellow','red'], light:seq(['violet','orange','aqua','blue','magenta','green','yellow','red'],LIGHT) },
    sequential:{ hue:'violet', light:rampFor(283) },
    light: lightTokens({paper:'#FBF8F3',card:'#F3EEE6',ink:'#1F1B16',ink2:'#46403A',muted:'#6A6258',faint:'#A59C90',line:'#E5DED3',accent:'#3D2E8F'}),
    diverging:{ light: DIVERGING('#EFE9E0','light') } },
  controlroom: { label:'Salle de contrôle', usage:'Lecture à l\'écran en séance de travail : fond sombre. À l\'impression, bascule en clair avec les mêmes graphiques.',
    mood:'bleu nuit, cyan, grille discrète ; clair et sobre sur papier',
    fonts:{ display:'Sora', body:'IBM Plex Sans', data:'IBM Plex Mono', weights:{ display:[600,700], body:[400,500,600], data:[400,500] } },
    density:1.0, typePt:{ h1:25, h2:15, body:9.5, caption:8, data:7.5 },
    series:{ names:['blue','orange','aqua','yellow','magenta','green','violet','red'], light:seq(['blue','orange','aqua','yellow','magenta','green','violet','red'],LIGHT), dark:seq(['blue','orange','aqua','yellow','magenta','green','violet','red'],DARK) },
    sequential:{ hue:'blue', light:BLUE_REF, dark:BLUE_REF.slice().reverse() },
    light: lightTokens({paper:'#FFFFFF',card:'#F1F5F9',ink:'#0F172A',ink2:'#334155',muted:'#5B6B80',faint:'#94A3B8',line:'#E2E8F0',accent:'#0369A1'}),
    dark: darkTokens({paper:'#0B1220',card:'#131C2E',ink:'#E6EDF7',ink2:'#C3CFE0',muted:'#8FA0B8',faint:'#5F7089',line:'#23304A',accent:'#38BDF8'}),
    diverging:{ light: DIVERGING('#F0EFEC','light'), dark: DIVERGING('#2B3548','dark') } },
};
for (const p of Object.values(packs)) Object.assign(p, common);
fs.writeFileSync('packs.json', JSON.stringify({ version:1, generatedBy:'make-packs.mjs', packs }, null, 2));
console.log('packs.json écrit :', Object.keys(packs).join(', '));
