// Une seule source pour un pack : le CSS (variables) ET le thème ECharts sortent des mêmes jetons.
// Fonctions pures, sans dépendance : utilisables côté serveur (finalisation HTML) et dans la page d'aperçu.

export function googleFontsHref(pack){
  const f = pack.fonts, fam = n => encodeURIComponent(n).replace(/%20/g,'+');
  const uniq = [...new Set([f.display, f.body, f.data])];
  const spec = n => { const w = new Set(); if(n===f.display) f.weights.display.forEach(x=>w.add(x)); if(n===f.body) f.weights.body.forEach(x=>w.add(x)); if(n===f.data) f.weights.data.forEach(x=>w.add(x)); return `family=${fam(n)}:wght@${[...w].sort((a,b)=>a-b).join(';')}`; };
  return `https://fonts.googleapis.com/css2?${uniq.map(spec).join('&')}&display=swap`;
}

function tokenVars(t, pack, mode){
  const v = {
    '--paper':t.paper,'--card':t.card,'--ink':t.ink,'--ink-2':t.ink2,'--muted':t.muted,'--faint':t.faint,'--line':t.line,
    '--accent':t.accent,'--accent-text':t.accentText,'--accent-soft':t.accentSoft,
    '--risk':t.status.risk.fill,'--risk-text':t.status.risk.text,'--risk-soft':t.status.risk.soft,
    '--watch':t.status.watch.fill,'--watch-text':t.status.watch.text,'--watch-soft':t.status.watch.soft,
    '--ok':t.status.ok.fill,'--ok-text':t.status.ok.text,'--ok-soft':t.status.ok.soft,
    '--under':t.under,'--under-text':t.underText,
  };
  const series = mode==='dark' ? pack.series.dark : pack.series.light;
  series.forEach((c,i)=>{ v[`--series-${i+1}`]=c; });
  const seq = mode==='dark' ? (pack.sequential.dark || pack.sequential.light) : pack.sequential.light;
  seq.forEach((c,i)=>{ v[`--seq-${i+1}`]=c; });
  const d = pack.diverging[mode] || pack.diverging.light;
  d.good.forEach((c,i)=>{ v[`--div-good-${i+1}`]=c; }); d.bad.forEach((c,i)=>{ v[`--div-bad-${i+1}`]=c; }); v['--div-mid']=d.mid;
  return v;
}
const decl = o => Object.entries(o).map(([k,v])=>`  ${k}: ${v};`).join('\n');

/** CSS d'un pack. Sélecteur : [data-pack="id"]. Un pack avec variante sombre est sombre à l'écran et clair à l'impression. */
export function packCss(id, pack, { selector } = {}){
  const sel = selector || `[data-pack="${id}"]`;
  const f = pack.fonts, base = {
    '--font-display':`"${f.display}","Helvetica Neue",Arial,sans-serif`, '--font-body':`"${f.body}","Helvetica Neue",Arial,sans-serif`, '--font-data':`"${f.data}",ui-monospace,Menlo,monospace`,
    '--space':String(pack.density),
    '--pt-h1':pack.typePt.h1+'pt','--pt-h2':pack.typePt.h2+'pt','--pt-body':pack.typePt.body+'pt','--pt-caption':pack.typePt.caption+'pt','--pt-data':pack.typePt.data+'pt',
    '--chart-axis-px':pack.chart.axisFontPx+'px','--chart-line-w':String(pack.chart.lineWidth),'--bar-radius':pack.chart.barRadius+'px',
  };
  const screenTokens = pack.dark ? tokenVars(pack.dark, pack, 'dark') : tokenVars(pack.light, pack, 'light');
  const printTokens = tokenVars(pack.light, pack, 'light');
  let css = `${sel} {\n${decl({ ...base, ...screenTokens })}\n  color-scheme: ${pack.dark?'dark':'light'};\n  background: var(--paper); color: var(--ink); font-family: var(--font-body);\n}\n`;
  if (pack.dark) css += `@media print {\n  ${sel} {\n${decl(printTokens).replace(/^/gm,'  ')}\n    color-scheme: light;\n  }\n}\n`;
  return css;
}

/** Thème ECharts du pack, pour un mode donné ('light' = clair/impression, 'dark' = écran sombre). */
export function echartsTheme(pack, mode='light'){
  const t = mode==='dark' && pack.dark ? pack.dark : pack.light;
  const series = mode==='dark' && pack.dark ? pack.series.dark : pack.series.light;
  const f = `${pack.fonts.body}, Helvetica Neue, Arial, sans-serif`, fd = `${pack.fonts.data}, Menlo, monospace`;
  const axis = { axisLine:{ lineStyle:{ color:t.line } }, axisTick:{ show:false }, axisLabel:{ color:t.muted, fontFamily:fd, fontSize:pack.chart.axisFontPx }, splitLine:{ lineStyle:{ color:t.line, type:pack.chart.gridDash } } };
  return {
    color: series, backgroundColor:'transparent', animation:false,
    textStyle:{ fontFamily:f, color:t.ink },
    title:{ textStyle:{ color:t.ink, fontFamily:f, fontSize:pack.chart.titleFontPx, fontWeight:600 } },
    legend:{ textStyle:{ color:t.ink2, fontFamily:f, fontSize:pack.chart.legendFontPx }, itemWidth:14, itemHeight:8, icon:'roundRect' },
    tooltip:{ backgroundColor:t.card, borderColor:t.line, textStyle:{ color:t.ink, fontFamily:f, fontSize:12 } },
    categoryAxis:{ ...axis, splitLine:{ show:false } }, valueAxis:{ ...axis, axisLine:{ show:false } }, timeAxis:{ ...axis },
    line:{ lineStyle:{ width:pack.chart.lineWidth }, symbolSize:pack.chart.symbolSize, showSymbol:false },
    bar:{ itemStyle:{ borderRadius:[pack.chart.barRadius,pack.chart.barRadius,0,0], borderColor:t.paper, borderWidth:pack.chart.barGapPx/2 }, barMaxWidth:28 },
    visualMap:{ textStyle:{ color:t.muted } },
  };
}

/** Encodage secondaire obligatoire : tiret et marqueur différents par série, pour le noir et blanc et le daltonisme. */
export function applySeriesEncoding(option, pack){
  (option.series||[]).forEach((s,i)=>{
    if (s.type==='line'){ s.lineStyle = { ...(s.lineStyle||{}), type: pack.chart.dashByIndex[i % 8] }; s.symbol = pack.chart.symbolByIndex[i % 8]; s.symbolSize = pack.chart.symbolSize; s.showSymbol = (s.data||[]).length <= 30; }
  });
  return option;
}

/** Couleur d'une zone de charge (ACWR) : statuts réservés + icône et libellé côté rendu. */
export function zoneOf(value, pack){
  const [a,b,c] = pack.zones.thresholds, L = pack.zones.labels;
  return value < a ? { key:'under', label:L[0] } : value <= b ? { key:'ok', label:L[1] } : value <= c ? { key:'watch', label:L[2] } : { key:'risk', label:L[3] };
}
