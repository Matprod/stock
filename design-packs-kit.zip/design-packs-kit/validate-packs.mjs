// Contrôles automatiques des packs : contraste du texte, séries (validateur dataviz), rampes, niveaux de gris.
import fs from 'node:fs';
import { validate } from './validate_palette.mjs';
import { contrast, hex2oklab, hex2oklch } from './color.mjs';

const { packs } = JSON.parse(fs.readFileSync(new URL('./packs.json', import.meta.url)));
const rows = []; let fails = 0, warns = 0;
const add = (pack, check, status, detail) => { rows.push({ pack, check, status, detail }); if (status==='FAIL') fails++; if (status==='WARN') warns++; };
const Lof = h => hex2oklab(h)[0];

function textChecks(pack, mode, t){
  const pairs = [['ink',t.ink,t.paper,7],['ink2',t.ink2,t.paper,4.5],['muted/paper',t.muted,t.paper,4.5],['muted/card',t.muted,t.card,4.5],
    ['accentText/paper',t.accentText,t.paper,4.5],['accentText/card',t.accentText,t.card,4.5],['underText/card',t.underText,t.card,4.5]];
  for (const k of ['risk','watch','ok']){ pairs.push([`${k}.text/card`,t.status[k].text,t.card,4.5],[`${k}.text/soft`,t.status[k].text,t.status[k].soft,4.5]); }
  let worst = Infinity, worstName='';
  for (const [n,fg,bg,min] of pairs){ const c=contrast(fg,bg); if(c<worst){worst=c;worstName=n;} if(c<min) add(pack,`texte ${mode}`,'FAIL',`${n} ${c.toFixed(2)}:1 < ${min}:1`); }
  add(pack,`texte ${mode}`, worst>=4.5?'PASS':'FAIL', `pire contraste ${worst.toFixed(2)}:1 (${worstName}) ; ${pairs.length} paires`);
}
function seriesChecks(pack, mode, pal, surface, names){
  const r = validate(pal, { mode, surface });
  for (const [name, ok, detail] of r.report){
    const status = ok===true||ok==='pass' ? 'PASS' : ok==='relief'||ok==='warn' ? 'WARN' : 'FAIL';
    add(pack, `séries ${mode} · ${name}`, status, String(detail).slice(0,150));
  }
  if (names[names.length-1] !== 'red') add(pack,`séries ${mode} · rouge réservé`,'FAIL','le rouge doit être la dernière série (couleur de statut)'); else add(pack,`séries ${mode} · rouge réservé`,'PASS','rouge en dernière position');
  // niveaux de gris : écart de luminosité entre séries voisines
  const g=[]; for(let i=0;i<pal.length-1;i++) g.push(Math.abs(Lof(pal[i])-Lof(pal[i+1])));
  const low=g.filter(d=>d<0.08).length;
  add(pack,`séries ${mode} · niveaux de gris`, low? 'WARN':'PASS', low? `${low} paire(s) voisine(s) trop proches en gris : trait différencié par tiret et marqueur obligatoire`:'toutes les paires voisines sont distinctes en gris');
}
function rampCheck(pack, name, steps){
  const L=steps.map(Lof); const dir=Math.sign(L[L.length-1]-L[0]); let ok=true, minD=1;
  for(let i=1;i<L.length;i++){ const d=(L[i]-L[i-1])*dir; minD=Math.min(minD,d); if(d<=0.03) ok=false; }
  add(pack,`rampe ${name}`, ok?'PASS':'FAIL', `${steps.length} pas, L ${L[0].toFixed(2)} à ${L[L.length-1].toFixed(2)}, plus petit écart ${minD.toFixed(3)}`);
}
for (const [id,p] of Object.entries(packs)){
  textChecks(id,'clair',p.light);
  if (p.dark) textChecks(id,'sombre',p.dark);
  seriesChecks(id,'light',p.series.light,p.light.paper,p.series.names);
  if (p.dark) seriesChecks(id,'dark',p.series.dark,p.dark.paper,p.series.names);
  rampCheck(id,'séquentielle (clair)',p.sequential.light);
  if (p.sequential.dark) rampCheck(id,'séquentielle (sombre)',p.sequential.dark);
  for (const mode of Object.keys(p.diverging)){
    const d=p.diverging[mode], mid=Lof(d.mid); const arms=[['bleu',d.good],['rouge',d.bad]];
    for (const [n,arm] of arms){ const dir = mode==='dark'?1:-1; const L=[mid,...arm.map(Lof)]; const ok=L.every((v,i)=>i===0||(v-L[i-1])*dir>0.02); add(p.label?id:id,`divergente ${mode} · bras ${n}`, ok?'PASS':'FAIL', `L ${L.map(v=>v.toFixed(2)).join(' > ')}`); }
  }
  add(id,'impression', p.light?'PASS':'FAIL', p.dark?'écran sombre + impression claire définis':'clair à l\'écran et à l\'impression');
}
const md = ['| Pack | Contrôle | Résultat | Détail |','| --- | --- | --- | --- |', ...rows.map(r=>`| ${r.pack} | ${r.check} | ${r.status} | ${r.detail.replace(/\|/g,'/')} |`)].join('\n');
fs.writeFileSync('validation-report.md', `# Rapport de validation des packs\n\n${md}\n\nÉchecs : ${fails} · Avertissements : ${warns}\n`);
fs.writeFileSync('validation-report.json', JSON.stringify({ fails, warns, rows }, null, 2));
const byStatus = rows.reduce((a,r)=>(a[r.status]=(a[r.status]||0)+1,a),{});
console.log(byStatus, 'échecs', fails);
for (const r of rows.filter(r=>r.status!=='PASS')) console.log(r.status, r.pack, '·', r.check, '·', r.detail);
process.exit(fails?1:0);
