# Kit « packs de design » (Report-v4)

Cinq packs de design pour rapports de données sportives, avec les fichiers qui les produisent, les valident et les rendent.
Le brief complet est dans le document « Packs de design pour rapports de données sportives (brief Cursor) ».

## Contenu

| Fichier | Rôle |
| --- | --- |
| `packs.json` | Les 5 packs (staff, medical, performance, editorial, controlroom). Source de vérité. Généré, ne pas éditer à la main. |
| `design-pack.types.ts` | Types TypeScript du contrat d'un pack (`DesignPack`, `PackFile`). |
| `pack-lib.mjs` | `packCss`, `echartsTheme`, `applySeriesEncoding`, `zoneOf`, `googleFontsHref`. Fonctions pures. |
| `make-packs.mjs` | Régénère `packs.json` (teintes, rampes, surfaces, statuts). |
| `validate-packs.mjs` | Valide chaque pack (écart daltonisme, vision normale, bande de luminosité, contraste du texte, niveaux de gris) et écrit `validation-report.md/.json`. |
| `validate_palette.mjs`, `color.mjs` | Validateur de palette de la compétence de visualisation et outils de couleur (OKLab). |
| `build-preview.mjs` | Produit `pack-preview.html` : six panneaux (cinq packs, `controlroom` à l'écran et à l'impression). |
| `soft-ops.schema.json`, `soft-ops.example.json` | Schéma des opérations douces avec la nouvelle op `set_pack`. |
| `previews/` | Captures des six panneaux (polices de repli : le bac à sable n'avait pas accès aux polices). |

## Commandes

    node make-packs.mjs        # régénère packs.json (résultat identique si rien n'a changé)
    node validate-packs.mjs    # attendu : 0 FAIL ; les WARN connus sont expliqués dans le brief
    node build-preview.mjs     # régénère pack-preview.html

Aucune dépendance : Node 18 ou plus.

## Résultat de validation livré

65 PASS, 9 WARN, 0 FAIL. Les WARN sont des contrastes sous 3:1 (aqua, jaune, magenta sur fond clair : étiquettes visibles ou tableau obligatoire) et des couples voisins trop proches en niveaux de gris (tiret et marqueur obligatoires).

## À savoir

- Couleurs de marque, accents et polices : propositions à valider.
- Le fichier de pack existant du dépôt (`report_design_pack.ts`) n'a pas été vu : l'intégration est à faire contre lui.
- La barrière « toutes les paires » (nuages de points, bulles, cartes) n'est pas validée sur les nouveaux ordres : limiter à 3 séries.
- `resolveTokens(option, pack, mode)` et le motif de hachures ne sont pas dans `pack-lib.mjs` : à écrire.
- Polices à héberger en `woff2` pour le PDF.
