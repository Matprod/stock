# Rapport de validation des packs

| Pack | Contrôle | Résultat | Détail |
| --- | --- | --- | --- |
| staff | texte clair | PASS | pire contraste 4.53:1 (underText/card) ; 13 paires |
| staff | séries light · Lightness band | PASS | all 8 inside L 0.43–0.77 |
| staff | séries light · Chroma floor | PASS | all 8 >= 0.1 |
| staff | séries light · CVD separation | PASS | worst adjacent #eda100↔#1baf7a ΔE 9.1 (protan) · tritan 5.8 |
| staff | séries light · Normal-vision floor | PASS | worst adjacent #e87ba4↔#eda100 ΔE 19.6 (normal) |
| staff | séries light · Contrast vs surface | WARN | below 3:1 — relief required (visible labels or table view): [["#1baf7a",2.82],["#eda100",2.17],["#e87ba4",2.69]] |
| staff | séries light · rouge réservé | PASS | rouge en dernière position |
| staff | séries light · niveaux de gris | WARN | 3 paire(s) voisine(s) trop proches en gris : trait différencié par tiret et marqueur obligatoire |
| staff | rampe séquentielle (clair) | PASS | 7 pas, L 0.91 à 0.34, plus petit écart 0.093 |
| staff | rampe séquentielle (sombre) | PASS | 7 pas, L 0.34 à 0.91, plus petit écart 0.093 |
| staff | divergente light · bras bleu | PASS | L 0.95 > 0.85 > 0.72 > 0.60 > 0.50 |
| staff | divergente light · bras rouge | PASS | L 0.95 > 0.85 > 0.72 > 0.60 > 0.50 |
| staff | divergente dark · bras bleu | PASS | L 0.34 > 0.42 > 0.50 > 0.58 > 0.66 |
| staff | divergente dark · bras rouge | PASS | L 0.34 > 0.42 > 0.50 > 0.58 > 0.66 |
| staff | impression | PASS | clair à l'écran et à l'impression |
| medical | texte clair | PASS | pire contraste 4.59:1 (underText/card) ; 13 paires |
| medical | séries light · Lightness band | PASS | all 8 inside L 0.43–0.77 |
| medical | séries light · Chroma floor | PASS | all 8 >= 0.1 |
| medical | séries light · CVD separation | PASS | worst adjacent #e34948↔#eda100 ΔE 15.3 (deutan) · tritan 9.6 |
| medical | séries light · Normal-vision floor | PASS | worst adjacent #e34948↔#eda100 ΔE 20.8 (normal) |
| medical | séries light · Contrast vs surface | WARN | below 3:1 — relief required (visible labels or table view): [["#1baf7a",2.82],["#e87ba4",2.69],["#eda100",2.17]] |
| medical | séries light · rouge réservé | PASS | rouge en dernière position |
| medical | séries light · niveaux de gris | PASS | toutes les paires voisines sont distinctes en gris |
| medical | rampe séquentielle (clair) | PASS | 7 pas, L 0.93 à 0.36, plus petit écart 0.094 |
| medical | divergente light · bras bleu | PASS | L 0.95 > 0.85 > 0.72 > 0.60 > 0.50 |
| medical | divergente light · bras rouge | PASS | L 0.95 > 0.85 > 0.72 > 0.60 > 0.50 |
| medical | impression | PASS | clair à l'écran et à l'impression |
| performance | texte clair | PASS | pire contraste 4.61:1 (risk.text/soft) ; 13 paires |
| performance | séries light · Lightness band | PASS | all 8 inside L 0.43–0.77 |
| performance | séries light · Chroma floor | PASS | all 8 >= 0.1 |
| performance | séries light · CVD separation | PASS | worst adjacent #e34948↔#eda100 ΔE 15.3 (deutan) · tritan 9.6 |
| performance | séries light · Normal-vision floor | PASS | worst adjacent #e34948↔#eda100 ΔE 20.8 (normal) |
| performance | séries light · Contrast vs surface | WARN | below 3:1 — relief required (visible labels or table view): [["#1baf7a",2.82],["#e87ba4",2.69],["#eda100",2.17]] |
| performance | séries light · rouge réservé | PASS | rouge en dernière position |
| performance | séries light · niveaux de gris | PASS | toutes les paires voisines sont distinctes en gris |
| performance | rampe séquentielle (clair) | PASS | 7 pas, L 0.93 à 0.36, plus petit écart 0.093 |
| performance | divergente light · bras bleu | PASS | L 0.95 > 0.85 > 0.72 > 0.60 > 0.50 |
| performance | divergente light · bras rouge | PASS | L 0.95 > 0.85 > 0.72 > 0.60 > 0.50 |
| performance | impression | PASS | clair à l'écran et à l'impression |
| editorial | texte clair | PASS | pire contraste 4.56:1 (underText/card) ; 13 paires |
| editorial | séries light · Lightness band | PASS | all 8 inside L 0.43–0.77 |
| editorial | séries light · Chroma floor | PASS | all 8 >= 0.1 |
| editorial | séries light · CVD separation | PASS | worst adjacent #1baf7a↔#eb6834 ΔE 9.2 (deutan) · tritan 9.6 |
| editorial | séries light · Normal-vision floor | PASS | worst adjacent #e34948↔#eda100 ΔE 20.8 (normal) |
| editorial | séries light · Contrast vs surface | WARN | below 3:1 — relief required (visible labels or table view): [["#1baf7a",2.66],["#e87ba4",2.54],["#eda100",2.04]] |
| editorial | séries light · rouge réservé | PASS | rouge en dernière position |
| editorial | séries light · niveaux de gris | WARN | 1 paire(s) voisine(s) trop proches en gris : trait différencié par tiret et marqueur obligatoire |
| editorial | rampe séquentielle (clair) | PASS | 7 pas, L 0.93 à 0.36, plus petit écart 0.094 |
| editorial | divergente light · bras bleu | PASS | L 0.94 > 0.85 > 0.72 > 0.60 > 0.50 |
| editorial | divergente light · bras rouge | PASS | L 0.94 > 0.85 > 0.72 > 0.60 > 0.50 |
| editorial | impression | PASS | clair à l'écran et à l'impression |
| controlroom | texte clair | PASS | pire contraste 4.53:1 (underText/card) ; 13 paires |
| controlroom | texte sombre | PASS | pire contraste 4.58:1 (underText/card) ; 13 paires |
| controlroom | séries light · Lightness band | PASS | all 8 inside L 0.43–0.77 |
| controlroom | séries light · Chroma floor | PASS | all 8 >= 0.1 |
| controlroom | séries light · CVD separation | PASS | worst adjacent #eda100↔#1baf7a ΔE 9.1 (protan) · tritan 5.8 |
| controlroom | séries light · Normal-vision floor | PASS | worst adjacent #e87ba4↔#eda100 ΔE 19.6 (normal) |
| controlroom | séries light · Contrast vs surface | WARN | below 3:1 — relief required (visible labels or table view): [["#1baf7a",2.82],["#eda100",2.17],["#e87ba4",2.69]] |
| controlroom | séries light · rouge réservé | PASS | rouge en dernière position |
| controlroom | séries light · niveaux de gris | WARN | 3 paire(s) voisine(s) trop proches en gris : trait différencié par tiret et marqueur obligatoire |
| controlroom | séries dark · Lightness band | PASS | all 8 inside L 0.48–0.67 |
| controlroom | séries dark · Chroma floor | PASS | all 8 >= 0.1 |
| controlroom | séries dark · CVD separation | PASS | worst adjacent #c98500↔#199e70 ΔE 8.4 (protan) · tritan 8.7 |
| controlroom | séries dark · Normal-vision floor | PASS | worst adjacent #d55181↔#c98500 ΔE 19.3 (normal) |
| controlroom | séries dark · Contrast vs surface | PASS | all 8 >= 3:1 |
| controlroom | séries dark · rouge réservé | PASS | rouge en dernière position |
| controlroom | séries dark · niveaux de gris | WARN | 5 paire(s) voisine(s) trop proches en gris : trait différencié par tiret et marqueur obligatoire |
| controlroom | rampe séquentielle (clair) | PASS | 7 pas, L 0.91 à 0.34, plus petit écart 0.093 |
| controlroom | rampe séquentielle (sombre) | PASS | 7 pas, L 0.34 à 0.91, plus petit écart 0.093 |
| controlroom | divergente light · bras bleu | PASS | L 0.95 > 0.85 > 0.72 > 0.60 > 0.50 |
| controlroom | divergente light · bras rouge | PASS | L 0.95 > 0.85 > 0.72 > 0.60 > 0.50 |
| controlroom | divergente dark · bras bleu | PASS | L 0.33 > 0.42 > 0.50 > 0.58 > 0.66 |
| controlroom | divergente dark · bras rouge | PASS | L 0.33 > 0.42 > 0.50 > 0.58 > 0.66 |
| controlroom | impression | PASS | écran sombre + impression claire définis |

Échecs : 0 · Avertissements : 9
