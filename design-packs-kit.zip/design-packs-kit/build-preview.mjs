import fs from 'node:fs';
import { googleFontsHref } from './pack-lib.mjs';
const { packs } = JSON.parse(fs.readFileSync('packs.json','utf8'));
const lib = fs.readFileSync('pack-lib.mjs','utf8').replace(/^export /gm,'');
const fontLinks = [...new Set(Object.values(packs).map(p=>googleFontsHref(p)))].map(h=>`<link rel="stylesheet" href="${h}">`).join('\n');

const page = `<!DOCTYPE html>
<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Aperçu des packs de design</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
${fontLinks}
<script src="https://cdn.jsdelivr.net/npm/echarts@5.5.1/dist/echarts.min.js"></script>
<style>
  *{box-sizing:border-box} body{margin:0;background:#CBD5E1;font:14px/1.5 "IBM Plex Sans",Arial,sans-serif;color:#0F172A;padding:24px 16px}
  .intro{max-width:920px;margin:0 auto 20px;color:#0F172A} .intro h1{font:600 22px/1.2 "Sora",Arial,sans-serif;margin:0 0 6px} .intro p{margin:0;color:#334155}
  #packs-css{display:none}
  .pv{max-width:920px;margin:0 auto 28px;padding:28px 32px 30px;border-radius:6px;background:var(--paper);color:var(--ink);font-family:var(--font-body);font-size:var(--pt-body);box-shadow:0 12px 40px rgba(15,23,42,.25);border:1px solid var(--line)}
  .pv h2{font:600 var(--pt-h2)/1.2 var(--font-display);margin:0;letter-spacing:-.01em;text-wrap:balance}
  .pv .tag{font:500 11px var(--font-data);letter-spacing:.14em;text-transform:uppercase;color:var(--accent-text);display:flex;align-items:center;gap:8px;margin-bottom:6px}
  .pv .tag::before{content:"";width:18px;height:2px;background:var(--accent)} .pv .sub{color:var(--ink-2);margin:6px 0 16px;max-width:70ch}
  .sw{display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin:0 0 6px} .sw .lab{font:500 10px var(--font-data);text-transform:uppercase;letter-spacing:.1em;color:var(--muted);width:92px}
  .sw i{display:block;width:30px;height:18px;border-radius:3px;border:1px solid var(--line)}
  .kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:16px 0}
  .kpi{background:var(--card);border-top:3px solid var(--ink);padding:10px 12px;border-radius:2px} .kpi.risk{border-top-color:var(--risk)} .kpi.watch{border-top-color:var(--watch)} .kpi.ok{border-top-color:var(--ok)}
  .kpi .v{font:600 26px/1 var(--font-display);font-variant-numeric:tabular-nums} .kpi .l{font-size:11.5px;color:var(--muted);margin-top:6px}
  .grid2{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:12px} .fig .t{font:600 12px var(--font-body);margin-bottom:4px} .fig .c{height:210px}
  .chip{display:inline-flex;align-items:center;gap:5px;padding:1px 8px;border-radius:4px;font:500 10.5px var(--font-data);letter-spacing:.05em;text-transform:uppercase;white-space:nowrap}
  .chip.risk{background:var(--risk-soft);color:var(--risk-text)} .chip.watch{background:var(--watch-soft);color:var(--watch-text)} .chip.ok{background:var(--ok-soft);color:var(--ok-text)} .chip.under{background:var(--card);color:var(--under-text)}
  table{width:100%;border-collapse:collapse;font-size:12.5px;margin:6px 0 14px} th{font:500 10px var(--font-data);text-transform:uppercase;letter-spacing:.1em;color:var(--muted);text-align:left;padding:6px 8px;border-bottom:1px solid var(--muted)} td{padding:5px 8px;border-bottom:1px solid var(--line)} td.num{font-family:var(--font-data);text-align:right;font-variant-numeric:tabular-nums}
  .zones{display:flex;height:26px;border-radius:3px;overflow:hidden;gap:2px;margin:6px 0 4px} .zones div{display:flex;align-items:center;padding:0 8px;font:500 10.5px var(--font-data);text-transform:uppercase;letter-spacing:.05em}
  .zones .z-under{background:var(--card);color:var(--under-text);flex:0.8} .zones .z-ok{background:var(--ok-soft);color:var(--ok-text);flex:0.5} .zones .z-watch{background:var(--watch-soft);color:var(--watch-text);flex:0.2} .zones .z-risk{background:var(--risk-soft);color:var(--risk-text);flex:0.5}
  .callout{border-left:3px solid var(--accent);background:var(--accent-soft);padding:10px 14px;border-radius:0 4px 4px 0;margin-top:12px;color:var(--ink)} .callout.risk{border-left-color:var(--risk);background:var(--risk-soft)}
  .note{font-size:11.5px;color:var(--muted);margin:4px 0 12px}
  .typo{display:grid;grid-template-columns:auto 1fr;gap:2px 16px;align-items:baseline;margin:10px 0 14px} .typo span{font:500 10px var(--font-data);text-transform:uppercase;letter-spacing:.1em;color:var(--muted)}
  @media (max-width:760px){.pv{padding:18px}.kpis{grid-template-columns:1fr 1fr}.grid2{grid-template-columns:1fr}}
</style></head>
<body>
<div class="intro"><h1>Aperçu des packs de design</h1><p>Mêmes données, cinq packs. Le CSS et le thème des graphiques sortent des mêmes jetons (packs.json). La salle de contrôle est montrée à l'écran (sombre) puis à l'impression (clair).</p></div>
<style id="packs-css"></style>
<div id="root"></div>
<script>
${lib}
const PACKS = ${JSON.stringify(packs)};
const PANELS = [
  ['staff','staff','light'],['medical','medical','light'],['performance','performance','light'],['editorial','editorial','light'],
  ['controlroom','controlroom','dark'],['controlroom-print','controlroom','light']
];
const DAYS = Array.from({length:28},(_,i)=>i+1);
const wave = (a,p,b,ph=0)=>DAYS.map((d,i)=>+(b+a*Math.sin((i+ph)/p)+0.15*Math.cos(i/2.1+ph)).toFixed(2));
const SERIES = [['Charge externe (indice)',wave(0.9,4.2,2.6,0)],['Courbatures (1-6)',wave(0.5,5.5,2.4,1.5)],['Qualité du sommeil (1-6)',wave(0.4,6.8,2.2,3.1)],['Humeur (1-6)',wave(0.3,7.5,2.0,2)]];
const PLAYERS = ['Joueur A','Joueur B','Joueur C','Joueur D','Joueur E'];
const Z = [1.32,0.86,0.31,-0.52,-1.01];
const TISSUES = [['Ischio-jambiers',3],['Adducteurs',1],['Quadriceps',1],['Genou',1],['Épaule',1]];
const CSS = []; let root = document.getElementById('root');
PANELS.forEach(([pid,key,mode])=>{
  const base = PACKS[key];
  const pack = pid==='controlroom-print' ? Object.assign({}, base, { dark:undefined }) : base;
  const sel = '#pv-'+pid;
  CSS.push(packCss(key, pack, { selector: sel }).replace(/@media print\\s*\\{[\\s\\S]*?\\n\\}\\n/,''));
  const t = (mode==='dark'&&pack.dark)?pack.dark:pack.light, ser=(mode==='dark'&&pack.dark)?pack.series.dark:pack.series.light, seq=(mode==='dark'&&pack.sequential.dark)?pack.sequential.dark:pack.sequential.light;
  const dv = pack.diverging[mode]||pack.diverging.light;
  const sw = (label, arr)=>'<div class="sw"><span class="lab">'+label+'</span>'+arr.map(c=>'<i style="background:'+c+'" title="'+c+'"></i>').join('')+'</div>';
  const title = pack.label + (pid==='controlroom' ? ' · écran' : pid==='controlroom-print' ? ' · impression' : '');
  root.insertAdjacentHTML('beforeend', '<section class="pv" id="pv-'+pid+'">'+
    '<div class="tag">Pack '+title+'</div><h2>'+pack.usage.split('.')[0]+'</h2><p class="sub">'+pack.mood+'. Polices : '+pack.fonts.display+', '+pack.fonts.body+', '+pack.fonts.data+'.</p>'+
    sw('Surfaces',[t.paper,t.card,t.line,t.faint,t.muted,t.ink2,t.ink,t.accent])+
    sw('Statuts',[t.status.risk.fill,t.status.watch.fill,t.status.ok.fill,t.under])+
    sw('Séries 1 à 8',ser)+sw('Séquentielle',seq)+sw('Divergente',[...dv.good.slice().reverse(),dv.mid,...dv.bad])+
    '<div class="kpis"><div class="kpi risk"><div class="v">7</div><div class="l">blessures sur la période</div></div><div class="kpi risk"><div class="v">135</div><div class="l">jours d\\'indisponibilité</div></div><div class="kpi watch"><div class="v">18</div><div class="l">dosages de CK au-dessus du seuil</div></div><div class="kpi"><div class="v">2</div><div class="l">joueurs à surveiller</div></div></div>'+
    '<div class="grid2"><div class="fig"><div class="t">Wellness et charge, moyenne 7 jours</div><div class="c" id="l-'+pid+'"></div></div><div class="fig"><div class="t">Blessures par tissu</div><div class="c" id="b-'+pid+'"></div></div></div>'+
    '<div class="grid2"><div class="fig"><div class="t">Intensité par joueur et par jour (séquentielle)</div><div class="c" id="h-'+pid+'"></div></div><div class="fig"><div class="t">Écart à la référence personnelle (divergente)</div><div class="c" id="d-'+pid+'"></div></div></div>'+
    '<div class="t" style="font:600 12px var(--font-body)">Zone de charge (ACWR), seuils configurables</div><div class="zones"><div class="z-under">sous-charge</div><div class="z-ok">zone cible</div><div class="z-watch">vigilance</div><div class="z-risk">risque élevé</div></div><p class="note">Chaque zone porte un libellé : la couleur ne porte jamais seule le sens.</p>'+
    '<table><thead><tr><th>Date</th><th>Joueur</th><th>Lésion</th><th style="text-align:right">Jours</th><th>Statut</th></tr></thead><tbody>'+
    '<tr><td>25/09</td><td>Joueur A</td><td>Quadriceps</td><td class="num">17</td><td><span class="chip risk">En cours</span></td></tr>'+
    '<tr><td>06/09</td><td>Joueur D</td><td>Ischio-jambiers</td><td class="num">16</td><td><span class="chip ok">Rétabli</span></td></tr>'+
    '<tr><td>22/08</td><td>Joueur C</td><td>Ischio-jambiers</td><td class="num">5</td><td><span class="chip watch">Reprise</span></td></tr>'+
    '<tr><td>—</td><td>Joueur E</td><td>Charge sRPE</td><td class="num">0</td><td><span class="chip under">Inexploitable</span></td></tr></tbody></table>'+
    '<div class="callout"><b>Lecture.</b> Trois blessures surviennent dans la semaine qui suit le match du 19, avant une coupure de trois semaines.</div>'+
    '<div class="callout risk" style="margin-top:8px"><b>À surveiller.</b> Deux joueurs dépassent le seuil de vigilance sur la fenêtre récente.</div>'+
  '</section>');
});
document.getElementById('packs-css').textContent = CSS.join('\\n'); document.getElementById('packs-css').media='all';
const st = document.createElement('style'); st.textContent = CSS.join('\\n'); document.head.appendChild(st);
function draw(){
 PANELS.forEach(([pid,key,mode])=>{
  const base = PACKS[key]; const pack = pid==='controlroom-print' ? Object.assign({}, base, { dark:undefined }) : base;
  const useMode = (mode==='dark'&&pack.dark)?'dark':'light';
  const th = echartsTheme(pack, useMode); echarts.registerTheme('t-'+pid, th);
  const t = useMode==='dark'?pack.dark:pack.light, ser=useMode==='dark'?pack.series.dark:pack.series.light;
  const seq = (useMode==='dark'&&pack.sequential.dark)?pack.sequential.dark:pack.sequential.light, dv = pack.diverging[useMode]||pack.diverging.light;
  const mk = (id,opt)=>{ const c=echarts.init(document.getElementById(id+'-'+pid),'t-'+pid,{renderer:'svg'}); c.setOption(opt); return c; };
  mk('l', applySeriesEncoding({ grid:{left:34,right:8,top:52,bottom:26}, legend:{top:0,left:0,itemGap:12}, xAxis:{type:'category',data:DAYS,boundaryGap:false,axisLabel:{interval:6}}, yAxis:{type:'value',scale:true,splitNumber:4},
    series: SERIES.map(([n,d])=>({name:n,type:'line',data:d})) }, pack));
  mk('b', { grid:{left:112,right:24,top:6,bottom:22}, xAxis:{type:'value',splitNumber:3}, yAxis:{type:'category',data:TISSUES.map(x=>x[0]).reverse(),axisLabel:{color:t.ink2}},
    series:[{type:'bar',data:TISSUES.map((x,i)=>({value:x[1],itemStyle:{color:i===0?ser[0]:t.faint,borderRadius:[0,pack.chart.barRadius,pack.chart.barRadius,0]}})).reverse(),barWidth:16,label:{show:true,position:'right',color:t.ink2,fontFamily:pack.fonts.data}}] });
  const hd=[]; for(let y=0;y<5;y++) for(let x=0;x<14;x++) hd.push([x,y,+(Math.max(0,Math.sin((x+y*2)/2.2)*0.5+0.5+((x*y)%3)*0.08)).toFixed(2)]);
  mk('h', { grid:{left:70,right:8,top:6,bottom:40}, xAxis:{type:'category',data:Array.from({length:14},(_,i)=>i+1),splitArea:{show:false}}, yAxis:{type:'category',data:PLAYERS,axisLabel:{color:t.ink2}},
    visualMap:{min:0,max:1.2,calculable:false,orient:'horizontal',left:'center',bottom:0,itemWidth:12,itemHeight:90,inRange:{color:seq},textStyle:{color:t.muted}},
    series:[{type:'heatmap',data:hd,itemStyle:{borderColor:t.paper,borderWidth:2}}] });
  const stepOf=v=>Math.min(3,Math.floor(Math.abs(v)/0.45));
  mk('d', { grid:{left:70,right:16,top:6,bottom:22}, xAxis:{type:'value',min:-1.5,max:1.5,splitNumber:6}, yAxis:{type:'category',data:PLAYERS.slice().reverse(),axisLabel:{color:t.ink2},axisLine:{show:false}},
    series:[{type:'bar',data:Z.slice().reverse().map(v=>({value:v,itemStyle:{color:(v>0?dv.bad:dv.good)[stepOf(v)],borderRadius:v>0?[0,pack.chart.barRadius,pack.chart.barRadius,0]:[pack.chart.barRadius,0,0,pack.chart.barRadius]}})),barWidth:14,markLine:{silent:true,symbol:'none',lineStyle:{color:t.muted,type:'solid'},data:[{xAxis:0}],label:{show:false}}}] });
 });
}
(document.fonts&&document.fonts.ready?document.fonts.ready:Promise.resolve()).then(draw);
</script></body></html>`;
fs.writeFileSync('pack-preview.html', page);
console.log('pack-preview.html', page.length, 'octets');
